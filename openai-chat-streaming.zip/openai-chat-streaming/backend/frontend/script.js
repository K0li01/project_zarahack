// script.js
document.addEventListener('DOMContentLoaded', () => {
    const chatbox = document.getElementById('chatbox');
    const messageInput = document.getElementById('messageInput');
    const sendButton = document.getElementById('sendButton');
    const resetButton = document.getElementById('resetButton');
    const cvUploader = document.getElementById('cvUploader');
    const fileNameDisplay = document.getElementById('fileName');

    const BACKEND_URL = 'http://localhost:3000';

    let currentAssistantMessageElement = null;
    let selectedCvFile = null;

    cvUploader.addEventListener('change', function(event) {
        if (event.target.files && event.target.files.length > 0) {
            const file = event.target.files[0];
            selectedCvFile = file;
            fileNameDisplay.textContent = `Selected: ${file.name}`;
            console.log('File selected:', file.name, 'Type (browser):', file.type, 'Size:', file.size);
        } else {
            selectedCvFile = null;
            fileNameDisplay.textContent = '';
        }
    });

    // MODIFIED displayMessage function
    function displayMessage(text, senderClass, type = 'text') {
        const messageElement = document.createElement('div');
        messageElement.classList.add('message', senderClass); // e.g., 'user-message', 'assistant-message'
        if (type === 'error') {
            messageElement.classList.add('error'); // Add 'error' class specifically
        }

        // Check if it's an assistant message and not explicitly an error display
        if (senderClass === 'assistant-message' && type !== 'error') {
            if (window.marked && typeof window.marked.parse === 'function') {
                // Sanitize Markdown output if necessary, though marked.js is generally safe.
                // For critical applications, consider a sanitizer like DOMPurify:
                // messageElement.innerHTML = DOMPurify.sanitize(marked.parse(text));
                messageElement.innerHTML = marked.parse(text);
            } else {
                console.warn("Marked.js library not found or parse function is missing. Displaying raw text for assistant.");
                messageElement.textContent = text; // Fallback
            }
        } else {
            // For user, system, or error messages, use textContent to prevent XSS
            messageElement.textContent = text;
        }

        chatbox.appendChild(messageElement);
        chatbox.scrollTop = chatbox.scrollHeight;
        return messageElement;
    }


    async function sendMessage() {
        const messageText = messageInput.value.trim();
        if (!messageText && !selectedCvFile) {
            displayMessage("Please type a message or upload a CV.", 'system-message', 'error');
            return;
        }

        if (messageText) displayMessage(messageText, 'user-message'); // Uses textContent
        if (selectedCvFile) displayMessage(`Uploading CV: ${selectedCvFile.name}`, 'user-message'); // Uses textContent

        messageInput.value = '';
        sendButton.disabled = true;
        resetButton.disabled = true;
        // currentAssistantMessageElement will be created by displayMessage, which now handles Markdown
        currentAssistantMessageElement = displayMessage("HireSight AI is analyzing...", 'assistant-message');
        let firstChunk = true;

        try {
            let fetchOptions;
            const endpoint = `${BACKEND_URL}/chat`;
            const formData = new FormData();

            if (selectedCvFile) {
                formData.append('cv', selectedCvFile, selectedCvFile.name);
            }
            if (messageText) {
                formData.append('message', messageText);
            }

            if (selectedCvFile || messageText) {
                 fetchOptions = { method: 'POST', body: formData };
                 console.log("Sending via FormData.");
            } else {
                 updateAssistantMessage("Nothing to send.", true); // Uses updated updateAssistantMessage
                 // Re-enable buttons as we are not making a fetch call
                 sendButton.disabled = false;
                 resetButton.disabled = false;
                 currentAssistantMessageElement = null; // Clear the "analyzing" message
                 return;
            }

            const response = await fetch(endpoint, fetchOptions);

            if (!response.ok && response.headers.get("content-type") !== "text/event-stream") {
                let errorMsg = `Server error: ${response.status} ${response.statusText}`;
                try {
                    const errorData = await response.json();
                    errorMsg = errorData.error || errorData.message || await response.text() || errorMsg;
                } catch (e) { errorMsg = await response.text() || errorMsg; }
                updateAssistantMessage(`Error: ${errorMsg}`, true); // Uses updated updateAssistantMessage
            } else {
                const reader = response.body.getReader();
                const decoder = new TextDecoder();
                let buffer = '';
                let accumulatedResponse = ''; // To build the full Markdown string for parsing

                while (true) {
                    const { value, done } = await reader.read();
                    if (done) {
                        if (firstChunk && currentAssistantMessageElement?.textContent === "HireSight AI is analyzing...") {
                             // Pass 'false' for isError to updateAssistantMessage
                            updateAssistantMessage("Analysis complete. (Stream ended)", false);
                        }
                        break;
                    }
                    buffer += decoder.decode(value, { stream: true });
                    let eventEndIndex;
                    while ((eventEndIndex = buffer.indexOf('\n\n')) !== -1) {
                        const eventString = buffer.substring(0, eventEndIndex);
                        buffer = buffer.substring(eventEndIndex + 2);
                        if (eventString.startsWith('data: ')) {
                            const jsonDataString = eventString.substring(6);
                            if (jsonDataString.trim() === '[DONE]') {
                                if (firstChunk && currentAssistantMessageElement?.textContent === "HireSight AI is analyzing...") {
                                    // Pass 'false' for isError
                                    updateAssistantMessage("Analysis complete.", false);
                                }
                                currentAssistantMessageElement = null;
                                if (selectedCvFile) {
                                    cvUploader.value = null;
                                    selectedCvFile = null;
                                    fileNameDisplay.textContent = '';
                                }
                                return;
                            }
                            try {
                                const data = JSON.parse(jsonDataString);
                                if (data.error) {
                                    updateAssistantMessage(`Error: ${data.error}`, true);
                                } else if (data.content) {
                                    if (firstChunk) {
                                        accumulatedResponse = data.content;
                                        firstChunk = false;
                                    } else {
                                        accumulatedResponse += data.content;
                                    }
                                    // Update the assistant message bubble with parsed Markdown
                                    if (window.marked && currentAssistantMessageElement) {
                                        currentAssistantMessageElement.innerHTML = marked.parse(accumulatedResponse);
                                    } else if (currentAssistantMessageElement) { // Fallback if marked not found
                                        currentAssistantMessageElement.textContent = accumulatedResponse;
                                    }
                                    chatbox.scrollTop = chatbox.scrollHeight;
                                }
                            } catch (e) {
                                updateAssistantMessage('Error processing streamed data.', true);
                                console.error('Error parsing JSON from stream:', e, jsonDataString);
                            }
                        }
                    }
                }
            }
            if (currentAssistantMessageElement?.textContent === "HireSight AI is analyzing...") {
                updateAssistantMessage('Response stream ended unexpectedly or was empty.', true);
            }
        } catch (error) {
            updateAssistantMessage(`Client/Network Error: ${error.message}`, true);
            console.error('Fetch or client-side processing error:', error);
        } finally {
            sendButton.disabled = false;
            resetButton.disabled = false;
            if (currentAssistantMessageElement?.textContent === "HireSight AI is analyzing...") {
                 // Check if it's already an error message to avoid overwriting a more specific one
                if (!currentAssistantMessageElement.classList.contains('error')) {
                    updateAssistantMessage('Failed to get a complete response.', true);
                }
            }
             // Only nullify if it hasn't been handled by a successful [DONE] or specific error update
            if (currentAssistantMessageElement && currentAssistantMessageElement.textContent !== "Analysis complete." && !currentAssistantMessageElement.classList.contains('error')) {
                 // currentAssistantMessageElement = null; // Let it persist if it contains a final message/error
            } else if (currentAssistantMessageElement?.textContent === "HireSight AI is analyzing..."){
                currentAssistantMessageElement = null; // Clear "analyzing" if it's stuck
            }
        }
    }

    // MODIFIED updateAssistantMessage to also handle Markdown for non-error updates
    function updateAssistantMessage(text, isError = false) {
        if (!currentAssistantMessageElement) {
            // If no current element, create one (e.g. for errors after stream closed)
            currentAssistantMessageElement = displayMessage("", 'assistant-message', isError ? 'error' : 'text');
        }

        if (isError) {
            currentAssistantMessageElement.textContent = text; // Errors are plain text
            currentAssistantMessageElement.classList.add('error');
            // Ensure it's styled as an assistant message too for consistency if it wasn't already
            if (!currentAssistantMessageElement.classList.contains('assistant-message')) {
                 currentAssistantMessageElement.classList.add('assistant-message');
            }
        } else {
            // Non-error updates can be Markdown
            if (window.marked && typeof window.marked.parse === 'function') {
                currentAssistantMessageElement.innerHTML = marked.parse(text);
            } else {
                currentAssistantMessageElement.textContent = text; // Fallback
            }
            currentAssistantMessageElement.classList.remove('error');
        }
        chatbox.scrollTop = chatbox.scrollHeight;
    }


    async function resetChat() {
        if (!confirm("Are you sure you want to reset the session?")) return;
        sendButton.disabled = true; resetButton.disabled = true;
        cvUploader.value = null; selectedCvFile = null; fileNameDisplay.textContent = ''; messageInput.value = '';
        try {
            const response = await fetch(`${BACKEND_URL}/reset`, { method: 'POST' });
            chatbox.innerHTML = '';
            if (response.ok) {
                displayMessage("Session has been reset.", 'system-message'); // Uses textContent
                displayMessage("Hello! I'm HireSight AI. Provide job details or upload a CV.", 'assistant-message'); // Will use Markdown
            } else {
                const errorData = await response.json().catch(() => ({ message: "Unknown reset error" }));
                displayMessage(`Error resetting: ${errorData.message}`, 'system-message', 'error'); // Uses textContent
            }
        } catch (error) { displayMessage("Network error during reset.", 'system-message', 'error');} // Uses textContent
        finally { sendButton.disabled = false; resetButton.disabled = false; }
    }

    sendButton.addEventListener('click', sendMessage);
    messageInput.addEventListener('keypress', (e) => { if (e.key==='Enter'&&!e.shiftKey){e.preventDefault();sendMessage();}});
    resetButton.addEventListener('click', resetChat);
    // Initial greeting will now also be parsed by Markdown
    displayMessage("Hello! I'm HireSight AI, your assistant for preliminary candidate screening. To begin, please provide the full job description or key requirements for the position, or upload a candidate's CV.", 'assistant-message');
});