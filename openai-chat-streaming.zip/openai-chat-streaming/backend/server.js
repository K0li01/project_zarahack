// server.js
require('dotenv').config();
const express = require('express');
const OpenAI = require('openai');
const cors = require('cors');
const multer = require('multer');
const pdf = require('pdf-parse');
const mammoth = require('mammoth');

const app = express();
const port = process.env.PORT || 3000;

const storage = multer.memoryStorage();
const upload = multer({
    storage: storage,
    limits: { fileSize: 10 * 1024 * 1024 }, // 10MB
    fileFilter: (req, file, cb) => {
        console.log('[Multer FileFilter] Checking file:', file.originalname, 'MIME:', file.mimetype, 'Field:', file.fieldname);
        if (file.fieldname === 'cv') { // Only apply type validation to the 'cv' field
            if (
                file.mimetype === 'application/pdf' ||
                file.mimetype === 'text/plain' ||
                file.mimetype === 'application/vnd.openxmlformats-officedocument.wordprocessingml.document' || // .docx
                file.mimetype === 'application/msword' // .doc
            ) {
                cb(null, true); // Accept file
            } else {
                console.error('[Multer FileFilter] REJECTING. Unsupported type for "cv" field:', file.mimetype);
                cb(new Error(`Unsupported file type (${file.mimetype}) for CV. Allowed: PDF, TXT, DOC, DOCX.`), false);
            }
        } else {
             // If the fieldname is not 'cv', multer.fields will handle it as a non-file field if defined,
             // or reject if it's an unexpected file field.
             // We let other fields pass here, multer.fields definition will be the guide.
            cb(null, true);
        }
    }
});

if (!process.env.OPENAI_API_KEY) {
    console.error("FATAL ERROR: OPENAI_API_KEY is not set in .env file.");
    process.exit(1);
}
const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

app.use(cors());
app.use(express.json()); // For parsing application/json bodies (e.g., for /reset)

const HIRE_SIGHT_AI_SYSTEM_PROMPT = `You are HireSight AI, an intelligent assistant designed to help with preliminary screening of job candidates.
Your goal is to assess a candidate's suitability for a specific job position based on the information provided.

Here's how you will operate:
1.  The user will first provide you with the details of the **job position** (e.g., responsibilities, required skills, experience, education). Acknowledge receipt of the job description and ask for the candidate's details.
2.  Next, the user will provide you with the **candidate's information** (e.g., summary of their CV, key qualifications, skills, experience, education, possibly extracted from an uploaded document).
3.  You will then carefully analyze the candidate's information against the requirements of the job position.
4.  Provide a clear assessment:
    *   State whether the candidate appears to be a **strong match, a potential match (with some gaps), or not a good match** for the *specific position described*.
    *   Clearly list the **reasons for your assessment**, highlighting specific skills, experiences, or qualifications that align or misalign with the job requirements. Be objective and base your analysis solely on the information provided.
    *   Mention any **key strengths** of the candidate relevant to the role.
    *   Mention any **potential gaps or areas where the candidate might not meet all requirements**.
5.  If the candidate is not a good match for the *current position*, or even if they are a potential match but have other strong skills, consider if their profile might be **more suitable for a different type of position**. If so, suggest this possibility and ask the user if they would like to explore what kind of alternative roles might fit the candidate's profile based on the information given. For example: "While they may not be an ideal fit for the Senior Developer role due to lack of X years of specific experience, their strong project management skills and Y qualification might make them suitable for a Technical Project Coordinator role. Would you like me to elaborate on what kind of alternative roles might fit their profile?"

IMPORTANT:
*   You do NOT have access to external databases of candidates or jobs. Your entire analysis is based ONLY on the text provided by the user in this conversation (typed or from an uploaded document).
*   You are a preliminary screening assistant. You are NOT making final hiring decisions.
*   Avoid making definitive statements like "This person IS the perfect fit" or "This person IS NOT qualified." Instead, use phrases like "appears to be," "seems to align well," "might have a gap in," "based on the information provided."
*   If information is missing or unclear from either the job description or the candidate's profile, you can ask clarifying questions.
*   Maintain a professional, analytical, and helpful tone.`;


let conversationHistory = [{ role: "system", content: HIRE_SIGHT_AI_SYSTEM_PROMPT }];

// Using upload.fields() to explicitly define expected file and text fields
const handleUploads = upload.fields([
    { name: 'cv', maxCount: 1 },    // Expect one file in the 'cv' field
    { name: 'message', maxCount: 1} // Expect 'message' as a regular field, multer puts it in req.body
]);

app.post('/chat', handleUploads, async (req, res) => {
    let userMessageText = req.body.message || "";
    let extractedCvText = "";
    let fileProcessingMessage = "";

    const cvFileObject = (req.files && req.files.cv && req.files.cv[0]) ? req.files.cv[0] : null;

    console.log("Received POST /chat");
    console.log("req.body (populated by multer):", req.body);
    if (cvFileObject) {
        console.log("File from req.files.cv[0]:", cvFileObject.originalname, cvFileObject.mimetype, cvFileObject.size);
    } else {
        console.log("No 'cv' file found in req.files.");
    }

    if (cvFileObject) {
        try {
            const fileBuffer = cvFileObject.buffer;
            const originalName = cvFileObject.originalname; // No need for toLowerCase() here
            const mimeType = cvFileObject.mimetype;

            fileProcessingMessage = `(Processing file: ${originalName})`;

            if (mimeType === 'application/pdf' || originalName.toLowerCase().endsWith('.pdf')) {
                const data = await pdf(fileBuffer);
                extractedCvText = data.text.trim();
                fileProcessingMessage = extractedCvText ? `(Successfully extracted text from PDF: ${originalName})` : `(Could not extract text from PDF: ${originalName}. May be image-based or empty.)`;
            } else if (mimeType === 'text/plain' || originalName.toLowerCase().endsWith('.txt')) {
                extractedCvText = fileBuffer.toString('utf8').trim();
                fileProcessingMessage = extractedCvText ? `(Successfully extracted text from TXT: ${originalName})` : `(TXT file ${originalName} appears empty.)`;
            } else if (mimeType === 'application/vnd.openxmlformats-officedocument.wordprocessingml.document' || originalName.toLowerCase().endsWith('.docx')) {
                const result = await mammoth.extractRawText({ buffer: fileBuffer });
                extractedCvText = result.value.trim();
                fileProcessingMessage = extractedCvText ? `(Successfully extracted text from DOCX: ${originalName})` : `(DOCX file ${originalName} yielded no text.)`;
            } else if (mimeType === 'application/msword' || originalName.toLowerCase().endsWith('.doc')) {
                const result = await mammoth.extractRawText({ buffer: fileBuffer });
                extractedCvText = result.value.trim();
                fileProcessingMessage = extractedCvText ? `(Successfully extracted text from DOC: ${originalName})` : `(DOC file ${originalName} yielded no text.)`;
            } else {
                fileProcessingMessage = `[File type (${mimeType} for ${originalName}) not configured for parsing. Text not extracted.]`;
            }
            console.log(fileProcessingMessage);
        } catch (parseError) {
            extractedCvText = "";
            fileProcessingMessage = `[Error parsing content of ${cvFileObject.originalname}: ${parseError.message}]`;
            console.error("Error parsing file content:", parseError);
        }
    }

    let combinedUserMessage = userMessageText.trim();
    if (extractedCvText) {
        const cvContentForAI = `\n\n--- CV Content Extracted from ${cvFileObject.originalname} ---\n${extractedCvText}\n--- End CV Content ---`;
        combinedUserMessage = combinedUserMessage ? `${combinedUserMessage}\n${cvContentForAI}` : cvContentForAI.trim();
    } else if (cvFileObject && fileProcessingMessage) { // A file was uploaded but text extraction failed/empty
        const fileContextForAI = `\n\n[File Upload Status for ${cvFileObject.originalname}: ${fileProcessingMessage}]`;
        combinedUserMessage = combinedUserMessage ? `${combinedUserMessage}\n${fileContextForAI}` : fileContextForAI.trim();
    }

    if (!combinedUserMessage.trim()) {
        let feedbackMsg = "Please type a message or upload a supported CV (PDF/TXT/DOC/DOCX).";
        if (cvFileObject && fileProcessingMessage && !fileProcessingMessage.toLowerCase().includes("success")) {
            feedbackMsg = fileProcessingMessage; // Use the specific error from file processing
        }
        console.log("No effective message to send to OpenAI. Feedback:", feedbackMsg);
        res.setHeader('Content-Type', 'text/event-stream');
        res.setHeader('Cache-Control', 'no-cache');
        res.setHeader('Connection', 'keep-alive');
        res.flushHeaders();
        res.write(`data: ${JSON.stringify({ content: feedbackMsg })}\n\n`);
        res.write(`data: [DONE]\n\n`);
        return;
    }

    if (conversationHistory.length === 0 || conversationHistory[0].role !== "system") {
        conversationHistory.unshift({ role: "system", content: HIRE_SIGHT_AI_SYSTEM_PROMPT });
    }
    conversationHistory.push({ role: "user", content: combinedUserMessage });
    console.log("Sending to OpenAI (first 200 chars):", combinedUserMessage.substring(0, 200) + (combinedUserMessage.length > 200 ? "..." : ""));

    res.setHeader('Content-Type', 'text/event-stream');
    res.setHeader('Cache-Control', 'no-cache');
    res.setHeader('Connection', 'keep-alive');
    res.flushHeaders();

    try {
        const stream = await openai.chat.completions.create({
            model: "gpt-3.5-turbo",
            messages: conversationHistory,
            stream: true,
        });
        let assistantResponse = "";
        for await (const chunk of stream) {
            const content = chunk.choices[0]?.delta?.content || "";
            assistantResponse += content;
            if (content) res.write(`data: ${JSON.stringify({ content: content })}\n\n`);
        }
        if (assistantResponse.trim()) {
            conversationHistory.push({ role: "assistant", content: assistantResponse.trim() });
        }
        res.write(`data: [DONE]\n\n`);
    } catch (error) {
        console.error('Error streaming from OpenAI:', error);
        if (conversationHistory.length > 0 && conversationHistory[conversationHistory.length - 1].role === "user") {
            conversationHistory.pop(); // Remove last user message on OpenAI error
        }
        res.write(`data: ${JSON.stringify({ error: `OpenAI API Error: ${error.message || 'Unknown error'}` })}\n\n`);
        res.write(`data: [DONE]\n\n`);
    }
    req.on('close', () => console.log('Client disconnected from /chat stream.'));
});

// Multer error handling middleware (must be after routes using multer)
app.use((err, req, res, next) => {
    if (err instanceof multer.MulterError) { // Errors from Multer itself (e.g. file size)
        console.error("[Multer Error Caught] Name:", err.name, "Message:", err.message, "Field:", err.field, "Code:", err.code);
        res.status(400).setHeader('Content-Type', 'text/event-stream');
        res.setHeader('Cache-Control', 'no-cache');
        res.setHeader('Connection', 'keep-alive');
        res.flushHeaders();
        res.write(`data: ${JSON.stringify({ error: `File Upload Error: ${err.message}.` })}\n\n`);
        res.write(`data: [DONE]\n\n`);
    } else if (err) { // Errors from fileFilter (e.g., unsupported type)
        console.error("[FileFilter Error Caught] Message:", err.message);
        res.status(400).setHeader('Content-Type', 'text/event-stream');
        res.setHeader('Cache-Control', 'no-cache');
        res.setHeader('Connection', 'keep-alive');
        res.flushHeaders();
        res.write(`data: ${JSON.stringify({ error: `File Error: ${err.message}` })}\n\n`);
        res.write(`data: [DONE]\n\n`);
    } else {
        next();
    }
});

app.post('/reset', (req, res) => {
    console.log("Received POST /reset");
    conversationHistory = [{ role: "system", content: HIRE_SIGHT_AI_SYSTEM_PROMPT }];
    res.status(200).json({ message: "Chat history has been reset." });
});

app.listen(port, () => {
    console.log(`HireSight AI Backend server listening at http://localhost:${port}`);
});